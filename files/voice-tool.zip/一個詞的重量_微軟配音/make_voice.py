# -*- coding: utf-8 -*-
"""
一個詞的重量：用微軟 Edge 台灣語音（edge-tts）產生三支動畫的配音
旁白：曉臻 zh-TW-HsiaoChenNeural；老師、女孩：曉雨 zh-TW-HsiaoYuNeural；男孩：雲哲 zh-TW-YunJheNeural
完成後會產生「配音結果.zip」，把它傳回給 Claude。
"""
import asyncio, json, os, re, sys, zipfile, subprocess

VOICE_OVERRIDE = {}      # 例：{"旁白": "zh-TW-HsiaoYuNeural"}
RATE = "+0%"
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "配音結果")

def pip_upgrade():
    print("正在安裝／更新 edge-tts……")
    subprocess.call([sys.executable, "-m", "pip", "install", "-q", "-U", "edge-tts"])

pip_upgrade()
import edge_tts
print("edge-tts 版本：", getattr(edge_tts, "__version__", "?"))

def variants(item):
    v = VOICE_OVERRIDE.get(item["role"], item["voice"])
    t = item["speak"]
    t2 = re.sub(r"[「」『』（）()…]", "", t).replace("：", "，")
    t3 = re.sub(r"[！!？?]", "。", t2).replace("。。", "。")          # 驚嘆號、問號換成句號
    t4 = "嗯，" + t3 if len(re.sub(r"\W", "", t3)) <= 6 else t3      # 太短的句子前面加語助詞
    out = [(v, t), (v, t2), (v, t3), (v, t4)]
    for alt in ("zh-TW-HsiaoChenNeural", "zh-TW-HsiaoYuNeural", "zh-TW-YunJheNeural"):
        if alt != v:
            out.append((alt, t3))                                         # 最後備案：換聲音
    return out

async def one(item, path):
    last = None
    for voice, text in variants(item):
        for tries in range(3):
            try:
                await edge_tts.Communicate(text, voice, rate=RATE).save(path)
                if os.path.exists(path) and os.path.getsize(path) > 1000:
                    return voice
            except Exception as e:
                last = e
            await asyncio.sleep(1 + tries * 2)
    if os.path.exists(path):
        os.remove(path)
    raise RuntimeError(str(last))

async def main():
    data = json.load(open(os.path.join(HERE, "lines.json"), encoding="utf-8"))
    os.makedirs(OUT, exist_ok=True)
    total, failed = len(data["lines"]), []
    spk_path = os.path.join(OUT, "_text.json")
    try:
        spk = json.load(open(spk_path, encoding="utf-8"))
    except Exception:
        spk = {}
    for k, item in enumerate(data["lines"], 1):
        name = f'{item["film"]}_{item["shot"]}_{item["line"]}.mp3'
        path = os.path.join(OUT, name)
        if os.path.exists(path) and os.path.getsize(path) > 1000:
            same = spk.get(name) == item["speak"] if name in spk else not item.get("redo")
            if same:
                continue
            os.remove(path)   # 台詞或念法改過，重做這一句
        await asyncio.sleep(0.6)   # 每句之間稍微停一下，避免被伺服器擋
        try:
            v = await one(item, path)
            spk[name] = item["speak"]
            json.dump(spk, open(spk_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            print(f"[{k}/{total}] {item['role']}（{v}）：{item['subtitle']}")
        except Exception as e:
            failed.append(item["subtitle"])
            print(f"[{k}/{total}] 失敗，稍後可再執行一次：{item['subtitle']}（{e}）")
    if failed:
        print(f"\n有 {len(failed)} 句沒有成功。請確認網路後，再雙擊一次「Windows點這裡.bat」，只會補做失敗的句子。")
        if len(failed) == total:
            print("全部失敗：可能是學校網路擋住了微軟語音服務（speech.platform.bing.com），可以改用家裡的網路試試。")
        return
    json.dump({"rate": RATE, "override": VOICE_OVERRIDE}, open(os.path.join(OUT, "設定.json"), "w", encoding="utf-8"), ensure_ascii=False)
    zpath = os.path.join(HERE, "配音結果.zip")
    with zipfile.ZipFile(zpath, "w") as z:
        for fn in os.listdir(OUT):
            z.write(os.path.join(OUT, fn), fn)
    print("\n完成！請把這個檔案傳回給 Claude：", zpath)

asyncio.run(main())
input("\n按 Enter 關閉視窗……")
