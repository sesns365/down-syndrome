#!/bin/bash
cd "$(dirname "$0")"
python3 make_voice.py
