@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py make_voice.py
) else (
  python make_voice.py
)
pause
